import com.laofeng.gameJFrame;
import com.laofeng.loginJFrame;
import com.laofeng.regsterJFrame;

public class APP {
    public static void main(String[] args) {

        new gameJFrame();

        new loginJFrame();

        new regsterJFrame();
    }
}
