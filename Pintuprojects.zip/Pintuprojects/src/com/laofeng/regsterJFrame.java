package com.laofeng;

import javax.swing.*;

public class regsterJFrame extends JFrame {
    // 到idea中创建一个宽488像素，高500像素的注册界面
    public regsterJFrame(){
        this.setSize(488,500);
        this.setVisible(true);
        //抬头
        this.setTitle("注册");
        //界面永远在最上层
        this.setAlwaysOnTop(true);
        //界面居中
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(3);
    }
}
