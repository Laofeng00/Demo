package com.laofeng;



import javax.swing.*;
import javax.swing.border.BevelBorder;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Random;

public class gameJFrame extends JFrame implements KeyListener {
    private int [][] date = new int[4][4];
    int x = 0;
    int y = 0;

    public gameJFrame() {
        //初始化界面
        initJFrame();

        //初始化菜单
        initJMenuBar();

        //初始化数据（打乱）
        initData();


        //初始化图片
        initImage();

        //是否显示界面
        this.setVisible(true);

    }

    private void initData() {
        int[] temparr = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15};
        Random r = new Random();
        for (int i = 0; i < temparr.length; i++) {
            //获取数组中的随机索引
            int index = r.nextInt(temparr.length);
            //定义一个临时变量用于存储原本遍历得到的数组中的每个索引的原数据
            int temp = temparr[i];
            temparr[i] = temparr[index];
            temparr[index] = temp;
        }


        //一维数组长度遍历
        for (int i = 0; i < temparr.length; i++) {
            //判断遍历如果数组索引内的数据为0的话则执行
                if (temparr[i] == 0) {
                    //x用于记录二维数组中的【索引】【】
                    x = i / 4;
                    //y用于记录二维数组中的【】【索引】
                    y = i % 4;
                } else {
                    //i在小于4时除得到的数都为0（被整除）
                    //i在0时模于4则都为0 1摸于4则为1（被整除）
                    date[i / 4][i % 4] = temparr[i];
                }
        }


    }
    //定义图片方法

    private void initImage() {

        this.getContentPane().removeAll();

        //细节:
        //先加载的图片在上方，后加载的图片塞在下面。
        for (int i = 0; i < 4; i++) {

            for (int j = 0; j < 4; j++) {
                int num = date[i][j];
                //创建图片
                ImageIcon iconi1 = new ImageIcon("imge\\girl\\" + num + ".jpg");
                //创建管理区，将图片给到管理
                JLabel jlabel1 = new JLabel(iconi1);
                //将管理好的图片添加到调用者
                jlabel1.setBounds(105 * j + 90, 105 * i + 120, 105, 105);

                jlabel1.setBorder(new BevelBorder(1));

                this.getContentPane().add(jlabel1);
            }

        }
        JLabel background = new JLabel(new ImageIcon("imge\\background\\background.jpg"));
        background.setBounds(37, 10, 526, 582);
        this.getContentPane().add(background);

        this.getContentPane().repaint();
    }

    private void initJMenuBar() {
        //创建菜单
        JMenuBar jMenuBar = new JMenuBar();
        //创建菜单上面的两个对象
        JMenu setJMenu = new JMenu("设置");
        JMenu andJMenu = new JMenu("关于我们");
        //创建两个对象中的功能
        JMenuItem replease = new JMenuItem("重新游戏");
        JMenuItem relogin = new JMenuItem("重新登录");
        JMenuItem closegame = new JMenuItem("关闭游戏");

        JMenuItem Xcx = new JMenuItem("公众号");
        //将两个对象的条目功能添加到两个对象中
        setJMenu.add(replease).add(relogin);
        setJMenu.add(closegame);
        andJMenu.add(Xcx);
        //将两个对象添加到菜单中
        jMenuBar.add(setJMenu).add(andJMenu);
        //将最终得到的菜单设置到程序中
        this.setJMenuBar(jMenuBar);
    }

    private void initJFrame() {
        //到idea中创建一个宽603像素，高680像素的游戏主界面
        //宽高
        this.setSize(603, 680);
        //抬头
        this.setTitle("拼图游戏单机版 v1.0");
        //界面永远在最上层
        this.setAlwaysOnTop(true);
        //界面居中
        this.setLocationRelativeTo(null);
        //关闭方式
        this.setDefaultCloseOperation(3);
        //关闭初始化图片默认居中
        this.setLayout(null);
        //给整个界面添加键盘监听事件
        this.addKeyListener(this);
    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {

        int code = e.getKeyCode();

        if(code == 65){

            this.getContentPane().removeAll();

            JLabel imge = new JLabel(new ImageIcon("imge\\girl\\all.jpg"));

            imge.setBounds(90,117,420,420);

            this.getContentPane().add(imge).repaint();





        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        //对上下左右进行判断
        //左 37 上 38 右 39 下 40
        int code = e.getKeyCode();

        if (code == 37) {
            System.out.println("向左");
            if(y == 3){
                return;
            }

            //将0图片跟下面的图片进行交换
            //将下面的图片的索引赋值给0
            date[x][y]=date[x ][y + 1];
            //将0的图片的索引赋值给被交换的图片
            date[x][y + 1]=0;
            //位置变更后x进行++用于记录交换后0的所在位置
            y++;
            initImage();
        } else if (code == 38) {
            System.out.println("向上");
            if(x == 3){
                return;
            }

            //将0图片跟下面的图片进行交换
            //将下面的图片的索引赋值给0
            date[x][y]=date[x + 1][y];
            //将0的图片的索引赋值给被交换的图片
            date[x + 1][y]=0;
            //位置变更后x进行++用于记录交换后0的所在位置
            x++;
            initImage();
        } else if (code == 39) {
            System.out.println("向右");
            if(y == 0){
                return;
            }

            //将0图片跟下面的图片进行交换
            //将下面的图片的索引赋值给0
            date[x][y]=date[x ][y - 1];
            //将0的图片的索引赋值给被交换的图片
            date[x][y - 1]=0;
            //位置变更后x进行++用于记录交换后0的所在位置
            y--;
            initImage();
        } else if (code == 40) {
            System.out.println("向下");
            if(x == 0){
                return;
            }
            System.out.println("向下");
            //将0图片跟下面的图片进行交换
            //将下面的图片的索引赋值给0
            date[x][y]=date[x - 1][y];
            //将0的图片的索引赋值给被交换的图片
            date[x - 1][y]=0;
            //位置变更后x进行++用于记录交换后0的所在位置
            x--;
            initImage();


        }else if(code == 65){

                initImage();

        }

    }
}