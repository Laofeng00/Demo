package com.laofeng;

import javax.swing.*;

public class loginJFrame extends JFrame {
    // 到idea中创建一个宽488像素，高430像素的登录界面
    public loginJFrame(){
        this.setSize(488,430);
        this.setVisible(true);
        //抬头
        this.setTitle("登入");
        //界面永远在最上层
        this.setAlwaysOnTop(true);
        //界面居中
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(3);
    }
}
