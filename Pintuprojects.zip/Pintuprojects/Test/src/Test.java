import java.util.Random;

public class Test {
    public static void main(String[] args) {
        int[] arr = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15};
        Random r = new Random();
        for (int i = 0; i < arr.length; i++) {
            int number = r.nextInt(arr.length);
            //遍历数组的索引的原本数据
            int temp = arr[i];
            //每一个索引跟随机索引上的数据交换
            arr[i] = arr[number];
            arr[number] = temp;


        }
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i]+" ");
        }
        System.out.println();

        int [][] date=new int[4][4];
        //计数器思想
        int temp = 0;
        for (int i = 0; i < date.length; i++) {
            for (int j = 0; j < date[i].length; j++) {
                //为一维数组索引提供一个计数器，分批次添加到二维数组中
                date[i][j]=arr[temp];
                temp++;
            }

        }
        for (int i = 0; i < date.length; i++) {
            //内循环四次
            for (int j = 0; j < date.length; j++) {
                System.out.print(date[i][j]+" ");
            }
            System.out.println();
        }
    }
}

