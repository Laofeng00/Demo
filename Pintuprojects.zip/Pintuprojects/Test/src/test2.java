import java.util.Random;

public class test2 {
    //打乱一维数组
    //将一个二维数组分成四个一维数组
    //将一个一维数组添加到二维数组的四个一维数组中
    public static void main(String[] args) {
        int [] temparr ={0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15};
        Random r = new Random();
        for (int i = 0; i < temparr.length; i++) {
            //获取数组中的随机索引
            int index = r.nextInt(temparr.length);
            //定义一个临时变量用于存储原本遍历得到的数组中的每个索引的原数据
            int temp = temparr[i];
            temparr[i]=temparr[index];
            temparr[index]=temp;
        }
        for (int i = 0; i < temparr.length; i++) {
            System.out.print(temparr[i]+", ");
        }
        System.out.println();

        int [][] date = new int[4][4];
        int number = 0;
        //二维数组的长度遍历
        for (int i = 0; i < date.length; i++) {
            //循环长度为二维数组中的每一位一维数组的长度
            for (int j = 0; j < date[i].length; j++) {
                //遍历二维数组中的每个一维数组的数据
                //运用计数器思想为temparr提供索引
                date[i][j]=temparr[number];
                number++;
            }
        }
        for (int i = 0; i < date.length; i++) {
            for (int j = 0; j < date.length; j++) {
                System.out.print(date[i][j]+" ");
            }
            System.out.println();
        }
    }
}
